const Orders = [
  {
    productName: "COLUMBIA EL TAMBO",
    productNumber: "34562",
    paymentStatus: "Pending",
    shipping: "Declined",
  },
  {
    productName: "BURUNDI BUJUMBURA",
    productNumber: "657483",
    paymentStatus: "Paid",
    shipping: "Delivered",
  },
  {
    productName: "COLUMBIA EL TAMBO",
    productNumber: "34562",
    paymentStatus: "Paid",
    shipping: "Pending",
  },
  {
    productName: "ETHIOPIA NEGELE GURBITU",
    productNumber: "45632",
    paymentStatus: "Paid",
    shipping: "Delivered",
  },
  {
    productName: "BURUNDI BUJUMBURA",
    productNumber: "657483",
    paymentStatus: "Paid",
    shipping: "Delivered",
  },
  {
    productName: "COLUMBIA EL TAMBO",
    productNumber: "34562",
    paymentStatus: "Pending",
    shipping: "Declined",
  },
  {
    productName: "COLUMBIA EL TAMBO",
    productNumber: "34562",
    paymentStatus: "Paid",
    shipping: "Delivered",
  },
  {
    productName: "ETHIOPIA NEGELE GURBITU",
    productNumber: "45632",
    paymentStatus: "Paid",
    shipping: "Delivered",
  },
  {
    productName: "BRAZILIA CASCAVEL VERMELHA",
    productNumber: "98453",
    paymentStatus: "Pending",
    shipping: "Declined",
  },
  {
    productName: "COSTA RICA LAS LAJAS",
    productNumber: "57384",
    paymentStatus: "Paid",
    shipping: "Delivered",
  },
  {
    productName: "BRAZILIA CASCAVEL VERMELHA",
    productNumber: "98453",
    paymentStatus: "Paid",
    shipping: "Delivered",
  },
];
